#include "Person.h"


static int Compare(struct Person* lhs, struct Person* rhs)
{
    int result = CompareStrings(lhs->lastName, rhs->lastName);
    if (result != 0)
        return result;

    result = CompareStrings(lhs->firstName, rhs->firstName);
    if (result != 0)
        return result;

    result = CompareStrings(lhs->middleName, rhs->middleName);
    if (result != 0)
        return result;

    return lhs->birth_year - rhs->birth_year;
}

#define SWAP_VALUES(Type, a, b) \
{ \
    Type tmp = *a; \
    *a = *b; \
    *b = tmp; \
}

static void Swap(struct Person* lhs, struct Person* rhs)
{
    SWAP_VALUES(char*, &lhs->lastName, &rhs->lastName);
    SWAP_VALUES(char*, &lhs->firstName, &rhs->firstName);
    SWAP_VALUES(char*, &lhs->middleName, &rhs->middleName);
    SWAP_VALUES(unsigned, &lhs->birth_year, &rhs->birth_year);
}

void Sort(struct Person* persons, int count, enum SortType sortType)
{
    for (int i = 0; i < count - 1; i++)
    {
        for (int j = 0; j < count - i - 1; j++)
        {
            int cmp = Compare(&persons[j], &persons[j + 1]);
            if (sortType == Asc && cmp > 0 || sortType == Desc && cmp < 0)
                Swap(&persons[j], &persons[j + 1]);
        }
    }
}
