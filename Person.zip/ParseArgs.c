#include "Person.h"
#include <stdlib.h>
#include <string.h>

#define DEFAULT_STR_VALUE   "�� ������"
#define DEFAULT_AGE         18


char* DuplicateString(const char* s)
{
    char* result = malloc(strlen(s) + 1);
    strcpy(result, s);
    return result;
}

struct Person* PersonAppend(struct Person* arr, int count, const struct Person* p)
{
    struct Person* result = realloc(arr, sizeof(*arr) * (count + 1));
    result[count].birth_year = p->birth_year;
    result[count].firstName = DuplicateString(p->firstName);
    result[count].lastName = DuplicateString(p->lastName);
    result[count].middleName = DuplicateString(p->middleName);
    return result;
}

char** ParsePerson(char** argv, struct Person* p)
{
    while (*argv && CompareStrings(*argv, "-person") != 0)
    {
        if (CompareStrings(*argv, "--fn") == 0)
        {
            ++argv;
            p->firstName = *argv++;
        }
        else if (CompareStrings(*argv, "--ln") == 0)
        {
            ++argv;
            p->lastName = *argv++;
        }
        else if (CompareStrings(*argv, "--mn") == 0)
        {
            ++argv;
            p->middleName = *argv++;
        }
        else if (CompareStrings(*argv, "--age") == 0)
        {
            ++argv;
            p->birth_year = atoi(*argv++);
        }
        else
        {
            ++argv;
        }
    }
    if (!p->firstName)
        p->firstName = DEFAULT_STR_VALUE;
    if (!p->middleName)
        p->middleName = DEFAULT_STR_VALUE;
    if (!p->birth_year)
        p->birth_year = DEFAULT_AGE;
    return argv;
}

struct Person* ParseArgs(char** argv, int* outCount)
{
    struct Person* result = NULL;

    int count = 0;
    while (*argv)
    {
        if (CompareStrings(*argv, "-person") == 0)
        {
            struct Person current = { NULL, NULL, NULL, 0 };

            ++argv;
            argv = ParsePerson(argv, &current);
            result = PersonAppend(result, count, &current);
            ++count;
        }
        else
        {
            ++argv;
        }
    }
    *outCount = count;
    return result;
}
