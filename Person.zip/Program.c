﻿#include "Person.h"
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>


enum SortType RequestSortType()
{
    int choice = 0;
    puts("Тип сортировки:\n1. По возрастанию.\n2. По убыванию.");
    do
    {
        printf("%s ", ">>");
        if (scanf("%d", &choice) != 1 || choice != 1 && choice != 2)
        {
            puts("Неверный ввод.");
            while (getchar() != '\n')
                ;
        }
    } while (choice != 1 && choice != 2);
    return choice == 1 ? Asc : Desc;
}

int main(int argc, char** argv)
{
    int count = 0;
    struct Person* person_list = NULL;
    enum SortType sort_type;

    setlocale(LC_ALL, "");
    
    person_list = ParseArgs(argv + 1, &count);;
    sort_type = RequestSortType();
    Sort(person_list, count, sort_type);
    Print(person_list, count);

    for (int i = 0; i < count; i++)
    {
        free(person_list[i].lastName);
        free(person_list[i].firstName);
        free(person_list[i].middleName);
    }
    free(person_list);
    return 0;
}
