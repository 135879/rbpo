#include "Person.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SURNAME_HEADER      "�������"
#define NAME_HEADER         "���"
#define PATRONYMIC_HEADER   "��������"
#define AGE_HEADER          "�������"

#define WIDTH_AUX   20

static char* GetFormat(struct Person* persons, int count, size_t* outWidth)
{
    const char* format = "| %%-%ds | %%-%ds | %%-%ds |";
    char* result = NULL;
    size_t lenLastName = strlen(SURNAME_HEADER);
    size_t lenFirstName = strlen(NAME_HEADER);
    size_t lenMiddleName = strlen(PATRONYMIC_HEADER);

    for (int i = 0; i < count; i++)
    {
        size_t len = strlen(persons[i].lastName);
        if (len > lenLastName)
            lenLastName = len;

        len = strlen(persons[i].firstName);
        if (len > lenFirstName)
            lenFirstName = len;

        len = strlen(persons[i].middleName);
        if (len > lenMiddleName)
            lenMiddleName = len;
    }
    *outWidth = lenLastName + lenFirstName + lenMiddleName;

    size_t lenFormatString = snprintf(NULL, 0, format, lenLastName, lenFirstName, lenMiddleName);
    result = malloc(lenFormatString + 1);
    snprintf(result, lenFormatString + 1, format, lenLastName, lenFirstName, lenMiddleName);
    return result;
}

static void PrintHorizontalBorder(size_t width)
{
    for (size_t i = 0; i < width; i++)
        putchar('-');
    putchar('\n');
}

void Print(struct Person* persons, int count)
{
    size_t width = 0;
    char* format = GetFormat(persons, count, &width);

    PrintHorizontalBorder(width + WIDTH_AUX);
    printf(format, SURNAME_HEADER, NAME_HEADER, PATRONYMIC_HEADER);
    printf(" %s |\n", AGE_HEADER);
    PrintHorizontalBorder(width + WIDTH_AUX);
    for (int i = 0; i < count; i++)
    {
        printf(format, persons[i].lastName, persons[i].firstName, persons[i].middleName);
        printf("   %3u   |\n", persons[i].birth_year);
    }
    PrintHorizontalBorder(width + WIDTH_AUX);

    free(format);
}
