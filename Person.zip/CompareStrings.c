#include "Person.h"

int CompareStrings(const char* lhs, const char* rhs)
{
    unsigned char c1, c2;
    do
    {
        c1 = (unsigned char)*lhs++;
        c2 = (unsigned char)*rhs++;
        if (c1 == '\0')
            return c1 - c2;
    } while (c1 == c2);
    return c1 - c2;
}